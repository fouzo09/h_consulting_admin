<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HeuristicController extends Controller
{

    public function getHeuristic(){
        return view("front.heuristic");
    }   

    public function nousConaitre(){

    }

    public function nosService(){
        
    }

    public function notreEquipe(){
        
    }

    public function carriere(){
        
    }
}
